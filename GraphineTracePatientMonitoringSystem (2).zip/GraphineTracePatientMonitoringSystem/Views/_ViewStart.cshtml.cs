using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GraphineTracePatientMonitoringSystem.Views
{
    public class _ViewStartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
