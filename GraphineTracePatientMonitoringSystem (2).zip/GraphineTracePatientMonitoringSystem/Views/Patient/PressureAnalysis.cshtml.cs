using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GraphineTracePatientMonitoringSystem.Views.Patient
{
    public class _PatientSidebarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
