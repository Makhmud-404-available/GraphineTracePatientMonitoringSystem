using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GraphineTracePatientMonitoringSystem.Views.Patient
{
    public class ReviewClinicianModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
