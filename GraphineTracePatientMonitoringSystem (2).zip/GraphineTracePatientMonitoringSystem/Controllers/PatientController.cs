﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using GraphineTracePatientMonitoringSystem.Models;

namespace GraphineTracePatientMonitoringSystem.Controllers
{
    // Simple controller for the clinician-facing patient dashboard
    public class PatientController : Controller
    {
        // GET: /Patient/Index
        // Main dashboard page with heat map and metrics
        public IActionResult Index()
        {
            ViewBag.ActivePage = "Dashboard";
            ViewData["Title"] = "Patient Dashboard";

            // Create a simple model and fill heat map with random data
            var model = new PatientDashboardViewModel();

            var random = new Random();

            int maxValue = 0;
            int contactCells = 0;
            int totalCells = 32 * 32;

            // Fill 32x32 matrix with random values (1–255)
            for (int row = 0; row < 32; row++)
            {
                for (int col = 0; col < 32; col++)
                {
                    int value = random.Next(1, 256); // 1 to 255
                    model.HeatMapValues[row, col] = value;

                    // track max pressure
                    if (value > maxValue)
                    {
                        maxValue = value;
                    }

                    // count “contact area” as cells above a simple threshold
                    if (value >= 100)
                    {
                        contactCells++;
                    }
                }
            }

            model.MaxPressureValue = maxValue;

            // Very simple formula for Peak Pressure Index (0–10 scale)
            model.PeakPressureIndex = Math.Round(maxValue / 255.0 * 10.0, 1);

            // Contact Area % (cells above 100)
            double percent = contactCells / (double)totalCells * 100.0;
            model.ContactAreaPercent = Math.Round(percent, 1);

            // Simple rule for alert banner
            if (maxValue >= 180)
            {
                model.HasHighPressureAlert = true;
                model.AlertMessage = "High pressure region detected in last 10 minutes.";
            }
            else
            {
                model.HasHighPressureAlert = false;
                model.AlertMessage = "No critical pressure regions at the moment.";
            }

            return View(model);
        }

        // GET: /Patient/PressureAnalysis
        // Simple analysis page with a list of readings
        public IActionResult PressureAnalysis()
        {
            ViewBag.ActivePage = "Analysis";
            ViewData["Title"] = "Patient Pressure Analysis";

            // Fake data for now (normally this would come from a database)
            var readings = new List<PressureReading>
            {
                new PressureReading
                {
                    DateTime = DateTime.Today.AddHours(9),
                    MetricName = "Peak Pressure Index",
                    Value = "8.7",
                    RiskLevel = "High",
                    BodyArea = "Lower back"
                },
                new PressureReading
                {
                    DateTime = DateTime.Today.AddHours(8),
                    MetricName = "Contact Area %",
                    Value = "67.3%",
                    RiskLevel = "Moderate",
                    BodyArea = "Right hip"
                },
                new PressureReading
                {
                    DateTime = DateTime.Today.AddDays(-1).AddHours(20),
                    MetricName = "Peak Pressure Index",
                    Value = "6.2",
                    RiskLevel = "Moderate",
                    BodyArea = "Left heel"
                },
                new PressureReading
                {
                    DateTime = DateTime.Today.AddDays(-1).AddHours(10),
                    MetricName = "Contact Area %",
                    Value = "45.1%",
                    RiskLevel = "Low",
                    BodyArea = "Shoulders"
                }
            };

            return View(readings);
        }

        // GET: /Patient/ReviewClinician
        // Comments / review page (form is mostly static for now)
        public IActionResult ReviewClinician()
        {
            ViewBag.ActivePage = "Comments";
            ViewData["Title"] = "Comments";
            return View();
        }

        // GET: /Patient/Alerts
        // Alerts page with a small list of alerts
        public IActionResult Alerts()
        {
            ViewBag.ActivePage = "Alerts";
            ViewData["Title"] = "Alerts";

            // Fake alerts list
            var alerts = new List<Alert>
            {
                new Alert
                {
                    Time = DateTime.Today.AddHours(10).AddMinutes(12),
                    Title = "High blood pressure detected",
                    Message = "Please take BP reading now.",
                    Severity = "High"
                },
                new Alert
                {
                    Time = DateTime.Today.AddHours(9).AddMinutes(30),
                    Title = "No movement detected for 3 hours",
                    Message = "Please adjust your position.",
                    Severity = "Medium"
                },
                new Alert
                {
                    Time = DateTime.Today.AddHours(6),
                    Title = "Pressure returned to safe range",
                    Message = "Monitoring continues.",
                    Severity = "Normal"
                }
            };

            return View(alerts);
        }
    }
}
